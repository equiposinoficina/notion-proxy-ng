#!/bin/sh

echo "*** Cleanup extra-clean ***"
PASSPHRASE=$PASSPHRASE duplicity cleanup --extra-clean --force $URL
echo ""
echo "*** Remove all but 2 full backups ***"
PASSPHRASE=$PASSPHRASE duplicity remove-all-but-n-full 2 --force $URL
echo ""
echo "*** Cache size ***"
du -h /root/.cache/duplicity/|tail -n 1
