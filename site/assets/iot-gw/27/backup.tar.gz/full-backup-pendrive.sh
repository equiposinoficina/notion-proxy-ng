#!/bin/bash
source config

echo "sleeping 300s (ensure system bootup)"
sleep 300

echo "already mounted?"
mount | grep pendrive
if [ "$?" -ne "0" ];
then
    echo "trying to mount..."
    mount $DISK_PARTITION /mnt/pendrive
fi

echo "checking partition mounted again"
mount | grep pendrive
if [ "$?" -eq "0" ];
then
    mkdir -p /mnt/pendrive/docker-data
    mkdir -p /mnt/pendrive/duplicity
    echo "*** making rsync..."
    rsync -cavz /docker-data /mnt/pendrive/docker-data
    echo "*** making duplicity..."
    PASSPHRASE=$PASSPHRASE duplicity incremental --full-if-older-than 7D -v4 --volsize 100 /docker-data $URL_PENDRIVE
    echo "*** backup done"
    echo "*** duplicity cleanup..."
    PASSPHRASE=$PASSPHRASE duplicity cleanup --extra-clean --force $URL_PENDRIVE
    echo ""
    echo "*** Remove all but 2 full backups ***"
    PASSPHRASE=$PASSPHRASE duplicity remove-all-but-n-full 2 --force $URL_PENDRIVE
    echo "*** Cache size ***"
    du -h /root/.cache/duplicity/|tail -n 1
    echo "umounting pendrive"
    umount /mnt/pendrive
else
    echo "pendrive is not mounted properly"
    exit -1
fi
