
# PASSPHRASE=clausimetrica duplicity ftp://user:pass@hostname /tmp/restore

# PASSPHRASE=clausimetrica duplicity --file-to-restore nom_fitxer_o_directori_a_recuperar ftp://user:pass@hostname /tmp/restore

# PASSPHRASE=clausimetrica duplicity -t 3D --file-to-restore nom_fitxer_o_directori_a_recuperar ftp://user:pass@hostname /tmp/restore

