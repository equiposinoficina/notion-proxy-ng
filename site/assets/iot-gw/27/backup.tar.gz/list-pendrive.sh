#!/bin/bash

source config

PASSPHRASE=$PASSPHRASE duplicity collection-status $URL_PENDRIVE 2>&1

