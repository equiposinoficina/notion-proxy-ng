#!/bin/bash
source config

# Copias de seguridad propias de los servicios en contenedores
find /docker-data/ -name backup.sh -exec {} \;

PASSPHRASE=$PASSPHRASE duplicity incremental --full-if-older-than 1M -v4 --volsize 100 --exclude={"/root/.cache/*","/dev/*","/proc/*","/sys/*","/tmp/*","/run/*","/mnt/*","/media/*","/lost+found","/var/lib/lxcfs/*"} / $URL 2>&1

source /opt/backup/clean-online.sh
