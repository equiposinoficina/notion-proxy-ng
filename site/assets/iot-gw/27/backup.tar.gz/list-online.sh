#!/bin/bash

source config

PASSPHRASE=$PASSPHRASE duplicity collection-status $URL 2>&1

