#!/bin/bash

/usr/bin/sudo /sbin/shutdown -h now
